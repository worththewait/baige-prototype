(() => {
  "use strict";
  const { tools, findNavItem } = window.BaigeData;
  const { escapeHtml } = window.BaigeUI;
  const policy = window.BaigePermissions;
  const navRoot = document.querySelector("#wbNav");
  const host = document.querySelector("#pageHost");
  const state = { activeId: "home", activeChild: "" };
  // Keep each document mounted so its inputs and tool tabs survive menu changes.
  const pages = new Map();
  // The top bar carries three entries; deeper pages stay reachable from cards.
  const TOP_IDS = ["discover-knowledge", "discover-tools", "knowledge"];

  function renderNavigation() {
    navRoot.innerHTML = TOP_IDS.map((id) => {
      const item = findNavItem(id);
      if (!item) return "";
      const active = state.activeId === id;
      return `<button class="wb-nav-item ${active ? "is-active" : ""}" data-nav="${id}" ${active ? 'aria-current="page"' : ""}>${escapeHtml(item.label)}</button>`;
    }).join("");
  }

  function normalizeRoute(id, child = "") {
    const item = findNavItem(id);
    if (!item) return null;
    const allowed = id === "smart-tools" ? tools.some((tool) => tool.name === child) : item.children?.includes(child);
    return { id, child: typeof child === "string" && allowed ? child : "" };
  }

  function activateFrame(page) {
    if (!page.ready) return;
    page.element.contentWindow.postMessage({
      type: "baige:activate", pageId: state.activeId,
      child: state.activeChild, focusSearch: page.focusSearch,
    }, "*");
    page.focusSearch = false;
  }

  function setPage(id, child = "", { fromHistory = false, focusSearch = false } = {}) {
    const route = normalizeRoute(id, child);
    if (!route) return;
    if (!policy.canOpen(route.id, route.child)) return setPage("home");
    const item = findNavItem(route.id);
    if (item.children && !route.child) route.child = item.children.find((name) => policy.canOpen(item.id, name)) || "";
    for (const [key, page] of pages) {
      if (key !== route.id && !page.element.hidden) {
        page.element.contentWindow.postMessage({ type: "baige:deactivate", pageId: key }, "*");
        page.element.hidden = true;
      }
    }
    state.activeId = route.id;
    state.activeChild = route.child;
    let page = pages.get(item.id);
    if (!page) {
      const frame = document.createElement("iframe");
      frame.className = "wb-frame";
      frame.title = item.label;
      frame.src = `${item.file}${route.child ? `#${encodeURIComponent(route.child)}` : ""}`;
      page = { element: frame, ready: false, focusSearch: false };
      pages.set(item.id, page);
      host.append(frame);
    }
    page.focusSearch ||= focusSearch;
    page.element.hidden = false;
    document.title = `${route.child || item.label} · 百舸数智平台`;
    renderNavigation();
    activateFrame(page);
    const hash = `#${route.id}${route.child ? `/${encodeURIComponent(route.child)}` : ""}`;
    if (!fromHistory && location.hash !== hash) location.hash = hash;
  }

  // file:// documents have opaque origins. Accept messages only from the exact
  // child window registered for a known route, and validate every route value.
  window.addEventListener("message", (event) => {
    const message = event.data;
    if (!message || typeof message !== "object") return;
    const page = pages.get(message.pageId);
    if (!page || event.source !== page.element.contentWindow) return;
    if (message.type === "baige:ready") {
      page.ready = true;
      if (message.pageId === state.activeId) activateFrame(page);
    } else if (message.type === "baige:navigate" && message.pageId === state.activeId) {
      setPage(message.id, message.child, { focusSearch: message.focusSearch === true });
    }
  });

  navRoot.addEventListener("click", (event) => {
    const button = event.target.closest("[data-nav]");
    if (button) setPage(button.dataset.nav);
  });
  document.querySelector("#newTaskButton").addEventListener("click", () => setPage("qa", "对话"));
  document.querySelector(".wb-brand").addEventListener("click", (event) => {
    event.preventDefault(); setPage("home");
  });
  document.addEventListener("keydown", (event) => {
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
      event.preventDefault(); setPage("smart-tools", "", { focusSearch: true });
    }
  });
  function readRoute() {
    try {
      const [id, ...parts] = location.hash.slice(1).split("/");
      return normalizeRoute(id, decodeURIComponent(parts.join("/"))) || { id: "home", child: "" };
    } catch { return { id: "home", child: "" }; }
  }
  window.addEventListener("hashchange", () => {
    const route = readRoute();
    if (route.id !== state.activeId || route.child !== state.activeChild) setPage(route.id, route.child, { fromHistory: true });
  });
  const route = readRoute();
  setPage(route.id, route.child, { fromHistory: true });
})();
